import { NextResponse } from 'next/server';
import { auth } from '@/auth.config';
import axios from 'axios';
import { prisma } from '@/lib/prisma'; // Import the prisma client

export async function POST(request: Request) {
  const session = await auth();

  // Ensure user is authenticated and has a userId in the session
  if (!session?.accessToken || !session?.userId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    // Assume tiktokVideoId is sent in the request body from the frontend
    const { videoUrl, description, tiktokVideoId } = await request.json();

    // First, get the user's boards
    const boardsResponse = await axios.get('https://api.pinterest.com/v5/user/boards', {
      headers: {
        'Authorization': `Bearer ${session.accessToken}`,
      },
    });

    // For this example, we'll use the first board
    const boardId = boardsResponse.data.items[0].id;

    // Create the pin
    const pinResponse = await axios.post(
      'https://api.pinterest.com/v5/pins',
      {
        board_id: boardId,
        media_source: {
          source_type: 'video_url',
          url: videoUrl,
        },
        title: description,
        description: `Reposted from TikTok: ${description}`,
      },
      {
        headers: {
          'Authorization': `Bearer ${session.accessToken}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const createdPinId = pinResponse.data.id; // Get the created pin ID from Pinterest

    // Save the posting record in the database
    try {
      await prisma.postedVideo.create({
        data: {
          userId: session.userId, // Use the userId from the session
          tiktokVideoId: tiktokVideoId, // Use the TikTok video ID from the request
          pinterestPinId: createdPinId, // Store the Pinterest pin ID
        },
      });
    } catch (dbError: any) {
      // Handle potential unique constraint violation (user already posted this video)
      if (dbError.code === 'P2002') {
        console.warn(`User ${session.userId} already posted TikTok video ${tiktokVideoId}`);
        // You might want to return a different status code or message here
      } else {
        console.error('Error saving posted video to database:', dbError);
        // Re-throw other database errors
        throw dbError;
      }
    }

    return NextResponse.json({ success: true, pin: pinResponse.data });
  } catch (error) {
    console.error('Error creating Pinterest pin:', error);

    // Consider more specific error handling for Pinterest API errors vs database errors

    return NextResponse.json(
      { error: 'Failed to create Pinterest pin' },
      { status: 500 }
    );
  }
} 