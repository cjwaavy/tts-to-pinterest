import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white p-4 mt-8">
      <div className="container mx-auto flex justify-center items-center text-sm">
        <Link href="/privacy-policy" className="hover:underline">
          Privacy Policy
        </Link>
        <span className="mx-2">|</span>
        {/* Add other footer links or information here */}
        <span>&copy; {new Date().getFullYear()} Winner's Circle TTS to Pin</span>
      </div>
    </footer>
  );
} 