'use client';

import { useSession, signOut, signIn } from 'next-auth/react';
import Link from 'next/link';

export default function Navbar() {
  const { data: session, status } = useSession();

  const isUserAuthenticated = status === 'authenticated';
  const isTikTokLinked = session?.isTikTokLinked;
  const isPinterestLinked = session?.isPinterestLinked;

  return (
    <nav className="bg-gray-800 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-xl font-bold">
          TikTok to Pinterest
        </Link>
        <div className="flex items-center space-x-4">
          {/* TikTok Status and Sign-in */}
          <div>
            {isUserAuthenticated ? (
              isTikTokLinked ? (
                <span className="text-green-500">TikTok Linked</span>
              ) : (
                <button
                  onClick={() => signIn('tiktok')}
                  className="px-3 py-1 text-sm bg-blue-600 rounded hover:bg-blue-700 transition-colors"
                >
                  Link TikTok
                </button>
              )
            ) : null}
          </div>

          {/* Pinterest Status and Sign-in */}
          <div>
             {isUserAuthenticated ? (
              isPinterestLinked ? (
                <span className="text-green-500">Pinterest Linked</span>
              ) : (
                <button
                  onClick={() => signIn('pinterest')}
                   className="px-3 py-1 text-sm bg-red-600 rounded hover:bg-red-700 transition-colors"
                >
                  Link Pinterest
                </button>
              )
            ) : null}
          </div>

          {/* Overall Logout Button */}
          <div>
            {isUserAuthenticated && (
              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="px-4 py-2 bg-gray-600 rounded hover:bg-gray-700 transition-colors"
              >
                Logout
              </button>
            )}
             {!isUserAuthenticated && (
                 <Link href="/auth/signin" className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700 transition-colors">
                     Sign In
                 </Link>
             )}
          </div>

        </div>
      </div>
    </nav>
  );
} 